import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;

public class MainTest {

    public static void main(String[] args) {

        String url = "https://www.metric-conversions.org/";
        String title = "Metric Conversion";
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        HomePage objHomePage;
        ResultsPage objResultsPage;

        TestCase test1 = new TestCase("Celsius", "1", "Fahrenheit", "1°C= 33.80000°F", "");
        TestCase test2 = new TestCase("Meters", "1", "Feet", "1m= 3ft 3.370079in", "");
        TestCase test3 = new TestCase("Ounces", "1", "Grams", "1oz= 28.34952g", "");

        ArrayList<TestCase> testCases = new ArrayList<>();
        testCases.add(test1);
        testCases.add(test2);
        testCases.add(test3);

        //  for additional test case  - remove comment from the next 6 lines
        //TestCase test4 = new TestCase("Ounces", "2", "Grams", "2oz= 56g", "");
        //TestCase test5 = new TestCase("Meters", "1", "Nanometer", "1m= 1000000000nm", "");
        //TestCase test6 = new TestCase("Ounces", "3", "Grams", "3oz= 85.04857g", "");
        //testCases.add(test4);
        //testCases.add(test5);
        //testCases.add(test6);

        for (int i = 0; i < testCases.size(); i++) {

            System.out.println("Test case #" + (i + 1) + ": started");
            driver.get(url);
            driver.manage().window().maximize();

            objHomePage = new HomePage(driver);
            objResultsPage = new ResultsPage(driver);

            wait.until(ExpectedConditions.titleContains(title));
            System.out.println("Home page: " + objHomePage.getTitle() + " was loaded successfully!");

            objHomePage.enterFromUnits(testCases.get(i).fromUnits);

            String titleFromTo = testCases.get(i).fromUnits + " to " + testCases.get(i).toUnits;
            String titleFromToXPath = "//h2[contains(text(), '" + titleFromTo + "')]";

            try {
                wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(titleFromToXPath)));
                WebElement elementFromTo = driver.findElement(By.xpath(titleFromToXPath));

                String convertButtonXPath = ".//following-sibling::div//child::a[contains(text(),'Convert')]";

                WebElement convertButton = elementFromTo.findElement(By.xpath(convertButtonXPath));
                convertButton.click();

                if (objResultsPage.verifyTitle(titleFromTo)) {

                    System.out.println("Navigated to " + titleFromTo + " page");
                    objResultsPage.enterNumber(testCases.get(i).fromNumber);

                    testCases.get(i).actualResult = objResultsPage.getAnswer();
                    if (testCases.get(i).actualResult.equals(testCases.get(i).expectedResult)) {
                        System.out.println(testCases.get(i).actualResult.toString());
                        System.out.println("Test case #" + (i + 1) + ": passed");
                    } else {
                        System.out.println("Test case #" + (i + 1) + ": failed");
                    }
                }

            } catch (NoSuchElementException | ElementNotVisibleException | TimeoutException e) {
                System.out.println("Exception in test case #" + (i + 1) + e.toString());
            }

        }
        driver.close();
    }

}