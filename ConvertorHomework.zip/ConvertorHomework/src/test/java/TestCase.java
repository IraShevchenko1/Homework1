public class TestCase {
    String fromUnits;
    String fromNumber;
    String toUnits;
    String expectedResult;
    String actualResult;

    public TestCase (String fromUnits, String fromNumber, String toUnits, String expectedResult, String actualResult){
        this.fromUnits = fromUnits;
        this.fromNumber = fromNumber;
        this.toUnits = toUnits;
        this.expectedResult = expectedResult;
        this.actualResult = actualResult;
    }

}
