import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ResultsPage {
    WebDriver driver;
    By answer = By.id("answer");
    By argument = By.id("argumentConv");

    public ResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    boolean verifyTitle(String titleToSearch) {

        List<WebElement> header = driver.findElements(By.xpath("//h1[contains(text(), '" + titleToSearch + "')]"));
        if (header.size() > 0) {
            return true;
        }
        return false;
    }

    public void enterNumber(String number) {
        driver.findElement(argument).sendKeys(number);
    }

    public String getAnswer() {
        return driver.findElement(answer).getText();
    }
}
