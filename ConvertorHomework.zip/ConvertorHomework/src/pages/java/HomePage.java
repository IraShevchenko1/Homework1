import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    WebDriver driver;
    By fromUnits = By.id("queryFrom");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void enterFromUnits(String unit) {
        driver.findElement(fromUnits).sendKeys(unit);
    }

}
