import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;

public class TestNGTest {

    String url = "https://www.metric-conversions.org/";
    WebDriver driver;
    WebDriverWait wait;
    HomePage objHomePage;
    ResultsPage objResultsPage;
    CreateResults objCreateResults;


    @DataProvider(name = "conversions")
    public Object[][] conversions() {
        return new Object[][]{
                {"Celsius", 2, "Fahrenheit"}, {"Meters", 1, "Feet"}, {"Ounces", 5, "Grams"}
        };
    }

    @Test(dataProvider = "conversions")
    public void conversionTest(String fromUnits, Integer argument, String toUnits) {

        objHomePage.enterFromUnits(fromUnits);
        String titleFromTo = fromUnits + " to " + toUnits;
        System.out.println("Convert from: " + argument + " " + titleFromTo);
        String titleFromToXPath = "//h2[contains(text(), '" + titleFromTo + "')]";
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(titleFromToXPath)));
        WebElement elementFromTo = driver.findElement(By.xpath(titleFromToXPath));
        objHomePage.clickConvert(elementFromTo);

        System.out.println("Navigated to " + objResultsPage.getTitle() + " page");
        objResultsPage.enterNumber(argument);
        System.out.println("Result is: " + objResultsPage.getAnswer());
        double actualResult = objCreateResults.parseAnswer(objResultsPage.getAnswer(), toUnits);
        System.out.println("Actual result rounded to 2 decimal places: " + actualResult);
        double expectedResult = objCreateResults.createExpected(fromUnits + toUnits, argument);
        System.out.println("Expected calculated result: " + expectedResult);
        Assert.assertEquals(actualResult, expectedResult);

    }

    @BeforeTest
    public void launchBrowser() {
        System.out.println("launching Chrome browser");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(url);
        driver.manage().window().maximize();
    }

    @BeforeMethod
    public void verifyHomepageTitle() {
        objHomePage = new HomePage(driver);
        objResultsPage = new ResultsPage(driver);
        objCreateResults = new CreateResults();

        String expectedTitle = "Metric Conversion charts and calculators";
        wait.until(ExpectedConditions.titleContains(expectedTitle));
        String actualTitle = objHomePage.getTitle();
        Assert.assertEquals(actualTitle, expectedTitle);
    }

    @AfterMethod
    public void goBackToHomepage() {
        objResultsPage.backToHomePage();
    }

    @AfterTest
    public void terminateBrowser() {
        driver.close();
    }
}
