import java.text.DecimalFormat;

public class CreateResults {
    public CreateResults() {
    }

    public static double createExpected (String fromTo, double num) {

        double result = 0;
        switch (fromTo){

            case "CelsiusFahrenheit":
                result = num*1.8+32;
                break;
            case "MetersFeet":
                result = num*3.2808398950131;
                break;
            case "OuncesGrams":
                result = num*28.349523125;
                break;
            default:
                System.out.println("add formula to support conversion: " + fromTo);
        }

        return roundTwoDecimals(result);
    }


    public static double parseAnswer(String answer, String toUnits) {

        double result = 0;

        // 1oz= 28.34952g
        int indEqual = answer.indexOf('=');
        int indDecimalPoint = answer.indexOf('.');

        if (toUnits.equals("Feet")) {
            //3ft 3.370079in
            int indFeet = answer.indexOf('f');
            String feetStr = answer.substring(indEqual + 1, indFeet);
            int feet = Integer.parseInt(feetStr.trim());
            String inchStr = answer.substring(indFeet + 2, indDecimalPoint + 4);
            double inch = Double.parseDouble(inchStr);
            result = feet + inch/12;
        } else {

            String resultStr = answer.substring(indEqual + 1, indDecimalPoint + 4);
            result = Double.parseDouble(resultStr);
        }
        return roundTwoDecimals(result);
    }

    public static double roundTwoDecimals(double d) {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
        return Double.valueOf(twoDForm.format(d));
    }

}
