import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class ResultsPage {
    WebDriver driver;
    By answer = By.id("answer");
    By argument = By.id("argumentConv");
    By home = By.xpath("//a[@class='home']");
    By title = By.xpath("//h1");

    public ResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterNumber(Integer number) {
        driver.findElement(argument).sendKeys(String.valueOf(number));
    }

    public String getTitle (){
        return driver.findElement(title).getText();
    }

    public String getAnswer() {
        return driver.findElement(answer).getText();
    }

    public void backToHomePage () {
        driver.findElement(home).click();
    }

}
