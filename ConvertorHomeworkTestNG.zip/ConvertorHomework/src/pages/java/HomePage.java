import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

    WebDriver driver;
    By fromUnits = By.id("queryFrom");

    String convertButtonXPath = ".//following-sibling::div//child::a[contains(text(),'Convert')]";
    By convert = By.xpath(convertButtonXPath);

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void enterFromUnits(String unit) {
        driver.findElement(fromUnits).sendKeys(unit);
    }

    public void clickConvert(WebElement element) {
        element.findElement(convert).click();
    }

}
